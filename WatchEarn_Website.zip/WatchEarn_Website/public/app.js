(() => {
  let balance = 120;
  let completed = 2;
  const done = new Set();
  const tasks = {
    video: { title: 'Sample sponsored video', text: 'In a real service, the approved provider would verify eligibility. This preview does not play an ad or verify a view.' },
    rules: { title: 'Explore reward rules', text: 'Good! Read the rules carefully. Real rewards must be funded and verified before they are credited.' },
    safety: { title: 'Safety check', text: 'Confirm you understand that these are sample points only and have no cash value.' }
  };
  const modal = document.getElementById('modal');
  const message = document.getElementById('taskMessage');
  let currentTask = null;
  document.querySelectorAll('.task-btn').forEach(btn => btn.addEventListener('click', () => {
    const id = btn.dataset.task;
    if (done.has(id)) return;
    currentTask = id;
    document.getElementById('modalTitle').textContent = tasks[id].title;
    document.getElementById('modalText').textContent = tasks[id].text;
    document.getElementById('confirmTask').textContent = `Complete demo task (+${btn.dataset.points} pts)`;
    modal.hidden = false;
  }));
  const closeModal = () => { modal.hidden = true; currentTask = null; };
  document.getElementById('closeModal').addEventListener('click', closeModal);
  modal.addEventListener('click', e => { if (e.target === modal) closeModal(); });
  document.getElementById('confirmTask').addEventListener('click', () => {
    if (!currentTask || done.has(currentTask)) return;
    const btn = document.querySelector(`[data-task="${currentTask}"]`);
    const points = Number(btn.dataset.points);
    done.add(currentTask); balance += points; completed++;
    document.getElementById('balance').textContent = balance;
    document.getElementById('completed').textContent = completed;
    btn.textContent = 'Completed'; btn.disabled = true; btn.style.opacity = '.55';
    const row = document.createElement('div'); row.className = 'ledger-row';
    const icon = document.createElement('span'); icon.className = 'ledger-icon'; icon.textContent = '✓';
    const info = document.createElement('div');
    const title = document.createElement('strong'); title.textContent = tasks[currentTask].title;
    const small = document.createElement('small'); small.textContent = 'Sample demo credit · No cash value';
    info.append(title, small);
    const amount = document.createElement('b'); amount.textContent = `+${points}`;
    row.append(icon, info, amount); document.getElementById('ledgerRows').prepend(row);
    message.textContent = `Demo task completed: +${points} sample points. These points have no cash value.`;
    closeModal();
  });
  const menu = document.querySelector('nav');
  document.getElementById('menuBtn').addEventListener('click', () => menu.classList.toggle('open'));
  menu.querySelectorAll('a').forEach(a => a.addEventListener('click', () => menu.classList.remove('open')));
})();
