# WatchEarn — Website Preview

Responsive dark-green front-end prototype for the WatchEarn concept. It is designed for mobile and desktop.

## Run it

Open `public/index.html` in a browser, or deploy the `public` folder as a **Static Site** on a static hosting provider.

## Important

- This is a front-end demo only. Sample points are stored in page memory and reset when the page reloads.
- There is no real sign-up, login, database, ad network, verified view tracking, UPI, or payout integration.
- Do not claim that demo points are money. Real reward systems require approved ad/sponsor arrangements, server-side verification, funded budgets, secure authentication, privacy/legal review, and an official payout integration.

## GitHub upload

Upload the *contents* of the `public` folder to the root of a separate repository if you want to host this as a static preview. For this demo, `index.html`, `styles.css`, and `app.js` should be in the same folder. Do not upload `.env` files or real credentials.
