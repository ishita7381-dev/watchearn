require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { Pool } = require('pg');
const bcrypt = require('bcryptjs');

async function main() {
  if (!process.env.DATABASE_URL) throw new Error('DATABASE_URL is required');
  const pool = new Pool({ connectionString: process.env.DATABASE_URL });
  try {
    const schema = fs.readFileSync(path.join(__dirname, '..', 'db', 'schema.sql'), 'utf8');
    await pool.query(schema);
    // Seed the two requested Shorts as external, unfunded videos. They do not automatically earn rewards.
    const seedVideos = [
      ['Featured Short 1', 'https://youtube.com/shorts/u4Jw7jj_R3E', 'u4Jw7jj_R3E'],
      ['Featured Short 2', 'https://youtube.com/shorts/8EhW1Y5q7Rc', '8EhW1Y5q7Rc']
    ];
    for (const [title, url, videoId] of seedVideos) {
      await pool.query(
        `INSERT INTO videos(title,url,youtube_video_id,campaign_type,reward_cents,required_seconds,active,funding_source)
         VALUES($1,$2,$3,'external',40,30,true,'unfunded') ON CONFLICT DO NOTHING`,
        [title, url, videoId]
      );
    }
    const email = (process.env.INITIAL_ADMIN_EMAIL || '').trim().toLowerCase();
    const password = process.env.INITIAL_ADMIN_PASSWORD || '';
    if (email && password) {
      if (password.length < 12) throw new Error('INITIAL_ADMIN_PASSWORD must be at least 12 characters');
      const existing = await pool.query('SELECT id FROM users WHERE email=$1', [email]);
      if (!existing.rowCount) {
        const hash = await bcrypt.hash(password, 12);
        const uid = 'WE-' + require('crypto').randomBytes(6).toString('hex').toUpperCase();
        await pool.query(
          'INSERT INTO users(uid,email,username,password_hash,role) VALUES($1,$2,$3,$4,$5)',
          [uid, email, 'WatchEarn Admin', hash, 'admin']
        );
        console.log('Created initial admin:', email, 'UID:', uid);
      } else {
        console.log('Admin email already exists; no password changes made.');
      }
    }
    console.log('Database schema ready.');
  } finally {
    await pool.end();
  }
}
main().catch(err => { console.error(err); process.exit(1); });
