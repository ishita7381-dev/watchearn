require('dotenv').config();
const express = require('express');
const session = require('express-session');
const PgSession = require('connect-pg-simple')(session);
const { Pool } = require('pg');
const bcrypt = require('bcryptjs');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const { z } = require('zod');
const crypto = require('crypto');
const path = require('path');

const app = express();
const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.PGSSL === 'true' ? { rejectUnauthorized: true } : undefined });
const isProd = process.env.NODE_ENV === 'production';

if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32) {
  throw new Error('SESSION_SECRET must be configured with at least 32 characters.');
}
app.set('trust proxy', isProd ? 1 : false);
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'"],
      imgSrc: ["'self'", "data:"],
      frameSrc: ["'self'", "https://www.youtube-nocookie.com", "https://www.youtube.com"],
      connectSrc: ["'self'"],
      objectSrc: ["'none'"],
      upgradeInsecureRequests: isProd ? [] : null
    }
  }
}));
app.use(express.json({ limit: '30kb' }));
app.use(express.urlencoded({ extended: false, limit: '30kb' }));
app.use(session({
  store: new PgSession({ pool, tableName: 'user_sessions', createTableIfMissing: true }),
  name: 'watchearn.sid',
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, secure: isProd, sameSite: 'lax', maxAge: 1000 * 60 * 60 * 24 * 7 }
}));
app.use('/api', rateLimit({ windowMs: 15 * 60 * 1000, limit: 250, standardHeaders: 'draft-7', legacyHeaders: false }));
app.use(express.static(path.join(__dirname, 'public')));

const asyncRoute = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
const money = cents => (cents / 100).toFixed(2);
const uid = () => 'WE-' + crypto.randomBytes(6).toString('hex').toUpperCase();

async function currentUser(req) {
  if (!req.session.userId) return null;
  const r = await pool.query('SELECT id,uid,email,username,role,status,created_at FROM users WHERE id=$1', [req.session.userId]);
  return r.rows[0] || null;
}
const requireAuth = asyncRoute(async (req, res, next) => {
  const user = await currentUser(req);
  if (!user || user.status !== 'active') return res.status(401).json({ error: 'Please sign in.' });
  req.user = user;
  next();
});
const requireAdmin = (req, res, next) => {
  if (!req.user || req.user.role !== 'admin') return res.status(403).json({ error: 'Admin access required.' });
  next();
};
async function audit(adminId, action, entityType, entityId, details = {}) {
  await pool.query(
    'INSERT INTO admin_audit_log(admin_user_id,action,entity_type,entity_id,details) VALUES($1,$2,$3,$4,$5)',
    [adminId, action, entityType, String(entityId), JSON.stringify(details)]
  );
}

app.get('/api/health', (req, res) => res.json({ ok: true, payoutsEnabled: process.env.PAYOUTS_ENABLED === 'true' }));

app.post('/api/auth/register', asyncRoute(async (req, res) => {
  const schema = z.object({
    email: z.string().email().max(254),
    username: z.string().trim().min(2).max(40).regex(/^[a-zA-Z0-9 _.-]+$/),
    password: z.string().min(12).max(128)
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Enter a valid email, username, and password of at least 12 characters.' });
  const email = parsed.data.email.toLowerCase().trim();
  const hash = await bcrypt.hash(parsed.data.password, 12);
  for (let i = 0; i < 3; i++) {
    try {
      const newUid = uid();
      const result = await pool.query(
        'INSERT INTO users(uid,email,username,password_hash) VALUES($1,$2,$3,$4) RETURNING id,uid,email,username,role,status,created_at',
        [newUid, email, parsed.data.username.trim(), hash]
      );
      req.session.regenerate(err => {
        if (err) return res.status(500).json({ error: 'Could not create session.' });
        req.session.userId = result.rows[0].id;
        res.status(201).json({ user: result.rows[0] });
      });
      return;
    } catch (e) {
      if (e.code === '23505' && e.constraint && e.constraint.includes('uid')) continue;
      if (e.code === '23505') return res.status(409).json({ error: 'An account with that email already exists.' });
      throw e;
    }
  }
  res.status(500).json({ error: 'Could not allocate UID; please retry.' });
}));

app.post('/api/auth/login', asyncRoute(async (req, res) => {
  const parsed = z.object({ email: z.string().email().max(254), password: z.string().min(1).max(128) }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Enter email and password.' });
  const result = await pool.query('SELECT id,password_hash,status FROM users WHERE email=$1', [parsed.data.email.toLowerCase().trim()]);
  const row = result.rows[0];
  if (!row || row.status !== 'active' || !(await bcrypt.compare(parsed.data.password, row.password_hash))) {
    return res.status(401).json({ error: 'Invalid email or password.' });
  }
  req.session.regenerate(err => {
    if (err) return res.status(500).json({ error: 'Could not create session.' });
    req.session.userId = row.id;
    res.json({ ok: true });
  });
}));
app.post('/api/auth/logout', (req, res) => req.session.destroy(() => {
  res.clearCookie('watchearn.sid', { httpOnly: true, sameSite: 'lax', secure: isProd });
  res.json({ ok: true });
}));
app.get('/api/me', requireAuth, asyncRoute(async (req, res) => {
  const [rewards, withdrawals, ledger] = await Promise.all([
    pool.query('SELECT r.id,r.amount_cents,r.status,r.source,r.created_at,v.title FROM rewards r LEFT JOIN videos v ON v.id=r.video_id WHERE r.user_id=$1 ORDER BY r.created_at DESC LIMIT 100', [req.user.id]),
    pool.query('SELECT id,amount_cents,payout_method,status,created_at,updated_at FROM withdrawals WHERE user_id=$1 ORDER BY created_at DESC LIMIT 100', [req.user.id]),
    pool.query(`SELECT
      COALESCE((SELECT SUM(amount_cents) FROM rewards WHERE user_id=$1 AND status IN ('approved','paid')),0)::int AS earned,
      COALESCE((SELECT SUM(amount_cents) FROM rewards WHERE user_id=$1 AND status='pending'),0)::int AS pending,
      COALESCE((SELECT SUM(amount_cents) FROM ledger_entries WHERE user_id=$1 AND entry_type='withdrawal_reserve'),0)::int -
      COALESCE((SELECT SUM(amount_cents) FROM ledger_entries WHERE user_id=$1 AND entry_type IN ('withdrawal_release','withdrawal_paid')),0)::int AS reserved`, [req.user.id])
  ]);
  const l = ledger.rows[0];
  const earned = l.earned;
  const pending = l.pending;
  const reserved = Math.max(0, l.reserved);
  res.json({
    user: req.user,
    balanceCents: Math.max(0, earned - reserved),
    pendingCents: pending,
    rewards: rewards.rows.map(r => ({ ...r, amount: money(r.amount_cents) })),
    withdrawals: withdrawals.rows.map(w => ({ ...w, amount: money(w.amount_cents) })),
    payoutsEnabled: process.env.PAYOUTS_ENABLED === 'true'
  });
}));

app.get('/api/videos', asyncRoute(async (req, res) => {
  const r = await pool.query('SELECT id,title,url,youtube_video_id,campaign_type,reward_cents,required_seconds,funding_source FROM videos WHERE active=true ORDER BY created_at DESC');
  res.json({ videos: r.rows });
}));

app.post('/api/withdrawals', requireAuth, asyncRoute(async (req, res) => {
  if (process.env.PAYOUTS_ENABLED !== 'true') return res.status(503).json({ error: 'Withdrawals are not enabled yet. The owner must configure and verify a payout provider first.' });
  const parsed = z.object({
    amountCents: z.number().int().min(2000).max(10000000),
    payoutMethod: z.string().trim().min(2).max(40),
    payoutAccountRef: z.string().trim().min(3).max(160)
  }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Minimum withdrawal is $20. Check the amount and payout details.' });
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const balanceQ = await client.query(`
      SELECT
        COALESCE((SELECT SUM(amount_cents) FROM rewards WHERE user_id=$1 AND status IN ('approved','paid')),0)::int AS earned,
        COALESCE((SELECT SUM(amount_cents) FROM ledger_entries WHERE user_id=$1 AND entry_type='withdrawal_reserve'),0)::int -
        COALESCE((SELECT SUM(amount_cents) FROM ledger_entries WHERE user_id=$1 AND entry_type IN ('withdrawal_release','withdrawal_paid')),0)::int AS reserved
      FROM users WHERE id=$1 FOR UPDATE`, [req.user.id]);
    const b = balanceQ.rows[0];
    const available = b.earned - Math.max(0, b.reserved);
    if (parsed.data.amountCents > available) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'Insufficient approved balance.' });
    }
    const w = await client.query(
      'INSERT INTO withdrawals(user_id,amount_cents,payout_method,payout_account_ref) VALUES($1,$2,$3,$4) RETURNING id,amount_cents,status,created_at',
      [req.user.id, parsed.data.amountCents, parsed.data.payoutMethod, parsed.data.payoutAccountRef]
    );
    await client.query(
      "INSERT INTO ledger_entries(user_id,withdrawal_id,entry_type,amount_cents) VALUES($1,$2,'withdrawal_reserve',$3)",
      [req.user.id, w.rows[0].id, parsed.data.amountCents]
    );
    await client.query('COMMIT');
    res.status(201).json({ withdrawal: w.rows[0], message: 'Request recorded for admin review. This is not a payment confirmation.' });
  } catch (e) {
    await client.query('ROLLBACK');
    throw e;
  } finally { client.release(); }
}));

// IMPORTANT: this endpoint does NOT verify YouTube views. Only a trusted, approved campaign/ad provider
// should call a production reward callback after its server-to-server verification.
app.post('/api/provider/reward-event', asyncRoute(async (req, res) => {
  const secret = process.env.REWARD_EVENT_SECRET || '';
  const provided = req.get('x-reward-event-secret') || '';
  if (!secret || provided.length !== secret.length || !crypto.timingSafeEqual(Buffer.from(provided), Buffer.from(secret))) {
    return res.status(401).json({ error: 'Invalid provider authentication.' });
  }
  const parsed = z.object({
    eventId: z.string().min(8).max(200),
    uid: z.string().min(4).max(40),
    videoId: z.string().uuid(),
    amountCents: z.number().int().min(1).max(10000),
    provider: z.enum(['sponsored_campaign', 'verified_ad_event'])
  }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Invalid event payload.' });
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const user = await client.query('SELECT id,status FROM users WHERE uid=$1 FOR UPDATE', [parsed.data.uid]);
    const video = await client.query('SELECT id,reward_cents,active,campaign_type,funding_source FROM videos WHERE id=$1 FOR UPDATE', [parsed.data.videoId]);
    if (!user.rowCount || user.rows[0].status !== 'active' || !video.rowCount || !video.rows[0].active) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'User or campaign is not eligible.' });
    }
    const v = video.rows[0];
    if (v.funding_source !== 'funded' || v.reward_cents !== parsed.data.amountCents) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'Campaign funding or configured reward does not match.' });
    }
    const source = parsed.data.provider;
    if (source === 'verified_ad_event' && v.campaign_type !== 'sponsored') {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'This campaign is not configured for verified ad events.' });
    }
    const inserted = await client.query(
      `INSERT INTO rewards(user_id,video_id,source_event_id,amount_cents,status,source,notes)
       VALUES($1,$2,$3,$4,'pending',$5,$6) ON CONFLICT DO NOTHING RETURNING id`,
      [user.rows[0].id, v.id, parsed.data.eventId, parsed.data.amountCents, source, 'Provider callback accepted; pending admin approval.']
    );
    if (!inserted.rowCount) {
      await client.query('ROLLBACK');
      return res.status(409).json({ error: 'Duplicate reward event or user already rewarded for this video.' });
    }
    await client.query('COMMIT');
    res.status(201).json({ ok: true, status: 'pending', rewardId: inserted.rows[0].id });
  } catch (e) {
    await client.query('ROLLBACK');
    if (e.code === '23505') return res.status(409).json({ error: 'Duplicate reward event.' });
    throw e;
  } finally { client.release(); }
}));

app.get('/api/admin/overview', requireAuth, requireAdmin, asyncRoute(async (req, res) => {
  const [users, rewards, withdrawals, videos, audits] = await Promise.all([
    pool.query("SELECT COUNT(*)::int AS total, COUNT(*) FILTER (WHERE status='active')::int AS active, COUNT(*) FILTER (WHERE status='suspended')::int AS suspended FROM users"),
    pool.query("SELECT COALESCE(SUM(amount_cents) FILTER (WHERE status='pending'),0)::int AS pending, COALESCE(SUM(amount_cents) FILTER (WHERE status IN ('approved','paid')),0)::int AS approved_paid FROM rewards"),
    pool.query("SELECT COUNT(*) FILTER (WHERE status='pending')::int AS pending_count, COALESCE(SUM(amount_cents) FILTER (WHERE status='pending'),0)::int AS pending_cents, COALESCE(SUM(amount_cents) FILTER (WHERE status='paid'),0)::int AS paid_cents FROM withdrawals"),
    pool.query("SELECT COUNT(*)::int AS total, COUNT(*) FILTER (WHERE active)::int AS active FROM videos"),
    pool.query('SELECT id,action,entity_type,entity_id,details,created_at FROM admin_audit_log ORDER BY created_at DESC LIMIT 20')
  ]);
  res.json({ users: users.rows[0], rewards: rewards.rows[0], withdrawals: withdrawals.rows[0], videos: videos.rows[0], audits: audits.rows });
}));
app.get('/api/admin/users', requireAuth, requireAdmin, asyncRoute(async (req, res) => {
  const r = await pool.query('SELECT id,uid,email,username,role,status,created_at FROM users ORDER BY created_at DESC LIMIT 500');
  res.json({ users: r.rows });
}));
app.get('/api/admin/withdrawals', requireAuth, requireAdmin, asyncRoute(async (req, res) => {
  const r = await pool.query('SELECT w.*,u.uid,u.email FROM withdrawals w JOIN users u ON u.id=w.user_id ORDER BY w.created_at DESC LIMIT 500');
  res.json({ withdrawals: r.rows });
}));
app.post('/api/admin/withdrawals/:id/review', requireAuth, requireAdmin, asyncRoute(async (req, res) => {
  const parsed = z.object({ decision: z.enum(['approve','reject','paid']), note: z.string().max(500).optional(), providerReference: z.string().max(160).optional() }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Invalid review action.' });
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const q = await client.query('SELECT * FROM withdrawals WHERE id=$1 FOR UPDATE', [req.params.id]);
    if (!q.rowCount) { await client.query('ROLLBACK'); return res.status(404).json({ error: 'Withdrawal not found.' }); }
    const w = q.rows[0];
    let next = w.status;
    if (parsed.data.decision === 'approve' && w.status === 'pending') next = 'approved';
    else if (parsed.data.decision === 'reject' && ['pending','approved'].includes(w.status)) next = 'rejected';
    else if (parsed.data.decision === 'paid' && w.status === 'approved') {
      if (!parsed.data.providerReference || parsed.data.providerReference.trim().length < 3) {
        await client.query('ROLLBACK');
        return res.status(400).json({ error: 'A real provider confirmation/reference is required before marking paid.' });
      }
      next = 'paid';
      await client.query("INSERT INTO ledger_entries(user_id,withdrawal_id,entry_type,amount_cents) VALUES($1,$2,'withdrawal_paid',$3)", [w.user_id, w.id, w.amount_cents]);
    } else {
      await client.query('ROLLBACK');
      return res.status(409).json({ error: `Cannot ${parsed.data.decision} a withdrawal in ${w.status} status.` });
    }
    await client.query(
      'UPDATE withdrawals SET status=$1,admin_note=$2,provider_reference=COALESCE($3,provider_reference),updated_at=now(),paid_at=CASE WHEN $1=$4 THEN now() ELSE paid_at END WHERE id=$5',
      [next, parsed.data.note || null, parsed.data.providerReference || null, 'paid', w.id]
    );
    if (next === 'rejected') {
      await client.query("INSERT INTO ledger_entries(user_id,withdrawal_id,entry_type,amount_cents) VALUES($1,$2,'withdrawal_release',$3)", [w.user_id, w.id, w.amount_cents]);
    }
    await audit(req.user.id, `withdrawal_${next}`, 'withdrawal', w.id, { amountCents: w.amount_cents, note: parsed.data.note || null });
    await client.query('COMMIT');
    res.json({ ok: true, status: next });
  } catch (e) {
    await client.query('ROLLBACK');
    throw e;
  } finally { client.release(); }
}));
app.post('/api/admin/videos', requireAuth, requireAdmin, asyncRoute(async (req, res) => {
  const parsed = z.object({
    title: z.string().trim().min(2).max(120),
    url: z.string().url().max(500).refine(v => ['https:', 'http:'].includes(new URL(v).protocol)),
    campaignType: z.enum(['external','sponsored']).default('external'),
    rewardCents: z.number().int().min(0).max(10000).default(40),
    requiredSeconds: z.number().int().min(0).max(3600).default(30),
    fundingSource: z.enum(['unfunded','funded']).default('unfunded')
  }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Invalid video/campaign details.' });
  const videoIdMatch = parsed.data.url.match(/(?:youtube\.com\/(?:shorts\/|watch\?v=)|youtu\.be\/)([A-Za-z0-9_-]{11})/);
  const result = await pool.query(
    `INSERT INTO videos(title,url,youtube_video_id,campaign_type,reward_cents,required_seconds,funding_source)
     VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
    [parsed.data.title, parsed.data.url, videoIdMatch ? videoIdMatch[1] : null, parsed.data.campaignType, parsed.data.rewardCents, parsed.data.requiredSeconds, parsed.data.fundingSource]
  );
  await audit(req.user.id, 'video_created', 'video', result.rows[0].id, { title: result.rows[0].title });
  res.status(201).json({ video: result.rows[0] });
}));
app.patch('/api/admin/videos/:id', requireAuth, requireAdmin, asyncRoute(async (req, res) => {
  const parsed = z.object({ title: z.string().trim().min(2).max(120).optional(), active: z.boolean().optional(), fundingSource: z.enum(['unfunded','funded']).optional(), rewardCents: z.number().int().min(0).max(10000).optional() }).safeParse(req.body);
  if (!parsed.success || Object.keys(parsed.data || {}).length === 0) return res.status(400).json({ error: 'Invalid update.' });
  const fields = [], values = [];
  for (const [key, value] of Object.entries(parsed.data)) {
    const col = ({ title: 'title', active: 'active', fundingSource: 'funding_source', rewardCents: 'reward_cents' })[key];
    values.push(value); fields.push(`${col}=$${values.length}`);
  }
  values.push(req.params.id);
  const result = await pool.query(`UPDATE videos SET ${fields.join(',')} WHERE id=$${values.length} RETURNING *`, values);
  if (!result.rowCount) return res.status(404).json({ error: 'Video not found.' });
  await audit(req.user.id, 'video_updated', 'video', req.params.id, parsed.data);
  res.json({ video: result.rows[0] });
}));
app.post('/api/admin/rewards/:id/review', requireAuth, requireAdmin, asyncRoute(async (req, res) => {
  const parsed = z.object({ decision: z.enum(['approve','reject']) }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Invalid decision.' });
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const q = await client.query('SELECT * FROM rewards WHERE id=$1 FOR UPDATE', [req.params.id]);
    if (!q.rowCount || q.rows[0].status !== 'pending') { await client.query('ROLLBACK'); return res.status(409).json({ error: 'Reward not found or no longer pending.' }); }
    const status = parsed.data.decision === 'approve' ? 'approved' : 'rejected';
    await client.query('UPDATE rewards SET status=$1,approved_at=CASE WHEN $1=$2 THEN now() ELSE approved_at END WHERE id=$3', [status, 'approved', req.params.id]);
    if (status === 'approved') await client.query("INSERT INTO ledger_entries(user_id,reward_id,entry_type,amount_cents) VALUES($1,$2,'reward_credit',$3)", [q.rows[0].user_id, q.rows[0].id, q.rows[0].amount_cents]);
    await audit(req.user.id, `reward_${status}`, 'reward', req.params.id, {});
    await client.query('COMMIT');
    res.json({ ok: true, status });
  } catch (e) { await client.query('ROLLBACK'); throw e; } finally { client.release(); }
}));

app.get('/terms', (req, res) => res.sendFile(path.join(__dirname, 'public', 'terms.html')));
app.get('/privacy', (req, res) => res.sendFile(path.join(__dirname, 'public', 'privacy.html')));
app.get('/reward-rules', (req, res) => res.sendFile(path.join(__dirname, 'public', 'reward-rules.html')));
app.get('/contact', (req, res) => res.sendFile(path.join(__dirname, 'public', 'contact.html')));

app.use((err, req, res, next) => {
  console.error(err);
  if (res.headersSent) return next(err);
  res.status(500).json({ error: isProd ? 'Server error.' : err.message || 'Server error.' });
});
const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`WatchEarn running on http://localhost:${port}`));
