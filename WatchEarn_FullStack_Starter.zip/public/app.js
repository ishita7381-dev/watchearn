const $ = s => document.querySelector(s);
let currentUser = null;
let signupMode = false;
let meData = null;
const fmt = cents => '$' + ((Number(cents || 0))/100).toFixed(2);
const escapeHtml = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
async function api(url, options={}) {
  const response = await fetch(url, { credentials:'same-origin', headers:{'Content-Type':'application/json', ...(options.headers||{})}, ...options });
  const data = await response.json().catch(()=>({}));
  if (!response.ok) throw new Error(data.error || 'Request failed');
  return data;
}
function toast(message) { const el=$('#toast'); el.textContent=message; el.classList.add('show'); setTimeout(()=>el.classList.remove('show'),2800); }
function showAuth(signup=false) {
  signupMode=signup; $('#authSection').hidden=false; $('#tabLogin').classList.toggle('active',!signup); $('#tabSignup').classList.toggle('active',signup);
  $('#usernameLabel').hidden=!signup; $('#usernameLabel').querySelector('input').required=signup;
  $('#authSubmit').textContent=signup?'Create account':'Log in'; $('#authForm').elements.password.autocomplete=signup?'new-password':'current-password';
  $('#authMessage').textContent=''; $('#authMessage').className='form-message'; $('#authSection').scrollIntoView({behavior:'smooth',block:'center'});
}
$('#showLogin').addEventListener('click',()=>showAuth(false));
$('#showSignup').addEventListener('click',()=>showAuth(true));
$('#heroJoin').addEventListener('click',()=>showAuth(true));
$('#tabLogin').addEventListener('click',()=>showAuth(false));
$('#tabSignup').addEventListener('click',()=>showAuth(true));
$('#authForm').addEventListener('submit',async e=>{
  e.preventDefault(); const f=new FormData(e.currentTarget); const payload={email:f.get('email'),password:f.get('password')}; if(signupMode)payload.username=f.get('username');
  const msg=$('#authMessage'); msg.textContent='Please wait…'; msg.className='form-message';
  try { await api(signupMode?'/api/auth/register':'/api/auth/login',{method:'POST',body:JSON.stringify(payload)}); msg.textContent=''; $('#authSection').hidden=true; await refresh(); toast(signupMode?'Account created!':'Welcome back!'); }
  catch(err){msg.textContent=err.message;msg.className='form-message error';}
});
$('#logoutBtn').addEventListener('click',async()=>{try{await api('/api/auth/logout',{method:'POST',body:'{}'});currentUser=null;meData=null;await refresh();toast('Logged out');}catch(e){toast(e.message)}});
function renderVideo(v) {
  const id=v.youtube_video_id;
  const frame=id?`<iframe loading="lazy" title="${escapeHtml(v.title)}" src="https://www.youtube-nocookie.com/embed/${encodeURIComponent(id)}" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>`:`<div class="video-placeholder"><div class="play-badge">▶</div><span>Open campaign</span></div>`;
  const href=escapeHtml(v.url);
  return `<article class="video-card"><div class="video-frame">${frame}</div><div class="video-info"><h3>${escapeHtml(v.title)}</h3><p>${v.campaign_type==='sponsored'?'Sponsored campaign':'External video'} · ${v.required_seconds||0}s campaign requirement</p><div class="video-meta"><span class="reward-tag">${v.funding_source==='funded'?fmt(v.reward_cents)+' eligible reward':'Reward not funded'}</span><a class="btn btn-ghost btn-small" href="${href}" target="_blank" rel="noopener noreferrer">Watch ↗</a></div></div></article>`;
}
async function loadVideos(){try{const d=await api('/api/videos');$('#videoGrid').innerHTML=d.videos.length?d.videos.map(renderVideo).join(''):'<div class="empty-state">No active videos yet. The admin can add campaigns.</div>';}catch(e){$('#videoGrid').innerHTML='<div class="empty-state">Could not load videos. Check that the server and database are running.</div>';}}
function status(s){return `<span class="status ${escapeHtml(s)}">${escapeHtml(s)}</span>`}
function table(headers, rows){return `<div class="table-wrap"><table><thead><tr>${headers.map(h=>`<th>${h}</th>`).join('')}</tr></thead><tbody>${rows.length?rows.join(''):`<tr><td colspan="${headers.length}">No records yet.</td></tr>`}</tbody></table></div>`}
async function loadAccount(){
  if(!currentUser){$('#accountPanel').className='panel empty-state';$('#accountPanel').textContent='Log in or create an account to view your account.';$('#heroBalance').textContent='$0.00';return;}
  try{meData=await api('/api/me');const d=meData;
    $('#heroBalance').textContent=fmt(d.balanceCents);
    const rewards=table(['Date','Campaign','Amount','Status'],d.rewards.map(r=>`<tr><td>${new Date(r.created_at).toLocaleDateString()}</td><td>${escapeHtml(r.title||r.source)}</td><td>${fmt(r.amount_cents)}</td><td>${status(r.status)}</td></tr>`));
    const withdrawals=table(['Date','Amount','Method','Status'],d.withdrawals.map(w=>`<tr><td>${new Date(w.created_at).toLocaleDateString()}</td><td>${fmt(w.amount_cents)}</td><td>${escapeHtml(w.payout_method)}</td><td>${status(w.status)}</td></tr>`));
    $('#accountPanel').className='panel';
    $('#accountPanel').innerHTML=`<div class="uid-row"><span>UID</span><strong class="uid-chip" id="uidValue">${escapeHtml(d.user.uid)}</strong><button class="btn btn-ghost btn-small" id="copyUid">Copy UID</button><span class="pill">${escapeHtml(d.user.role)}</span></div>
    <div class="account-grid"><div class="metric"><span>Available balance</span><strong>${fmt(d.balanceCents)}</strong></div><div class="metric"><span>Pending rewards</span><strong>${fmt(d.pendingCents)}</strong></div><div class="metric"><span>Minimum withdrawal</span><strong>$20.00</strong></div></div>
    <p class="micro">Account: ${escapeHtml(d.user.email)} · Joined ${new Date(d.user.created_at).toLocaleDateString()}</p>
    <h3 class="subhead">Request a withdrawal</h3><p class="micro">${d.payoutsEnabled?'Requests are subject to review and payout-provider eligibility.':'Withdrawals are currently disabled until the owner configures and verifies a payout provider.'}</p>
    <form id="withdrawForm" class="withdraw-form"><input class="field" type="number" name="amount" min="20" step="0.01" placeholder="Amount (min $20)" required ${d.payoutsEnabled?'':'disabled'}><select class="field" name="method" required ${d.payoutsEnabled?'':'disabled'}><option value="">Payout method</option><option value="paypal">PayPal (if enabled)</option><option value="bank_transfer">Bank transfer (if enabled)</option></select><input class="field" name="account" minlength="3" maxlength="160" placeholder="Payout account reference" required ${d.payoutsEnabled?'':'disabled'}><button class="btn btn-primary" ${d.payoutsEnabled?'':'disabled'}>Request payout</button></form>
    <h3 class="subhead">Earnings history</h3>${rewards}<h3 class="subhead">Withdrawal history</h3>${withdrawals}`;
    $('#copyUid').addEventListener('click',async()=>{try{await navigator.clipboard.writeText(d.user.uid);toast('UID copied');}catch(e){toast('Copy unavailable; select the UID manually.')}});
    $('#withdrawForm').addEventListener('submit',async e=>{e.preventDefault();const f=new FormData(e.currentTarget);try{await api('/api/withdrawals',{method:'POST',body:JSON.stringify({amountCents:Math.round(Number(f.get('amount'))*100),payoutMethod:f.get('method'),payoutAccountRef:f.get('account')})});toast('Request submitted for review');await loadAccount();}catch(err){toast(err.message)}});
  }catch(e){$('#accountPanel').textContent=e.message;}
}
async function loadAdmin(){
 if(!currentUser||currentUser.role!=='admin'){$('#admin').hidden=true;$('#adminNav').hidden=true;return;}
 $('#admin').hidden=false;$('#adminNav').hidden=false;
 try{
 const [d,users,ws,vids]=await Promise.all([api('/api/admin/overview'),api('/api/admin/users'),api('/api/admin/withdrawals'),api('/api/videos')]);
 $('#adminPanel').innerHTML=`<div class="admin-grid"><div class="metric"><span>Users / active</span><strong>${d.users.total} / ${d.users.active}</strong></div><div class="metric"><span>Pending rewards</span><strong>${fmt(d.rewards.pending)}</strong></div><div class="metric"><span>Pending withdrawals</span><strong>${d.withdrawals.pending_count}</strong></div><div class="metric"><span>Paid withdrawals</span><strong>${fmt(d.withdrawals.paid_cents)}</strong></div></div>
 <div class="admin-block"><h3 class="subhead">Add video / campaign</h3><form class="admin-form" id="videoForm"><input class="field" name="title" placeholder="Campaign title" required minlength="2" maxlength="120"><input class="field" name="url" type="url" placeholder="Video URL" required><select class="field" name="campaignType"><option value="external">External video (no reward proof)</option><option value="sponsored">Sponsored campaign</option></select><input class="field" name="reward" type="number" min="0" step=".01" value=".40" aria-label="Reward in USD"><select class="field" name="funding"><option value="unfunded">Unfunded</option><option value="funded">Funded (only if budget reserved)</option></select><button class="btn btn-primary">Add campaign</button></form></div>
 <div class="admin-block"><h3 class="subhead">Video campaigns</h3>${table(['Title','Reward','Funding','Action'],vids.videos.map(v=>`<tr><td>${escapeHtml(v.title)}</td><td>${fmt(v.reward_cents)}</td><td>${escapeHtml(v.funding_source)}</td><td><button class="btn btn-ghost btn-small" data-toggle-video="${v.id}" data-active="false">Disable</button></td></tr>`))}</div>
 <div class="admin-block"><h3 class="subhead">Withdrawal requests</h3>${table(['User','Amount','Method','Status','Actions'],ws.withdrawals.map(w=>`<tr><td>${escapeHtml(w.uid)}<br><small>${escapeHtml(w.email)}</small></td><td>${fmt(w.amount_cents)}</td><td>${escapeHtml(w.payout_method)}</td><td>${status(w.status)}</td><td><div class="admin-actions">${w.status==='pending'?`<button class="btn btn-primary btn-small" data-review="${w.id}" data-decision="approve">Approve</button><button class="btn btn-ghost btn-small danger" data-review="${w.id}" data-decision="reject">Reject</button>`:''}${w.status==='approved'?`<button class="btn btn-ghost btn-small" data-paid="${w.id}">Mark paid…</button>`:''}</div></td></tr>`))}</div>
 <div class="admin-block"><h3 class="subhead">Registered users</h3>${table(['UID','Email','Role','Status','Joined'],users.users.map(u=>`<tr><td>${escapeHtml(u.uid)}</td><td>${escapeHtml(u.email)}</td><td>${escapeHtml(u.role)}</td><td>${status(u.status)}</td><td>${new Date(u.created_at).toLocaleDateString()}</td></tr>`))}</div>
 <p class="notice">Outstanding liabilities and campaign funding must be reconciled against your real accounting system before launch. This dashboard does not connect to a bank or payment provider.</p>`;
 $('#videoForm').addEventListener('submit',async e=>{e.preventDefault();const f=new FormData(e.currentTarget);try{await api('/api/admin/videos',{method:'POST',body:JSON.stringify({title:f.get('title'),url:f.get('url'),campaignType:f.get('campaignType'),rewardCents:Math.round(Number(f.get('reward'))*100),requiredSeconds:30,fundingSource:f.get('funding')})});toast('Campaign added');await loadVideos();await loadAdmin();}catch(err){toast(err.message)}});
 document.querySelectorAll('[data-review]').forEach(b=>b.addEventListener('click',async()=>{try{await api(`/api/admin/withdrawals/${b.dataset.review}/review`,{method:'POST',body:JSON.stringify({decision:b.dataset.decision,note:'Reviewed in admin dashboard'})});toast('Withdrawal updated');await loadAdmin();await loadAccount();}catch(e){toast(e.message)}}));
 document.querySelectorAll('[data-paid]').forEach(b=>b.addEventListener('click',async()=>{const ref=prompt('Enter the real payout provider confirmation/reference. Do not enter a made-up value:');if(!ref)return;try{await api(`/api/admin/withdrawals/${b.dataset.paid}/review`,{method:'POST',body:JSON.stringify({decision:'paid',providerReference:ref,note:'Provider confirmation entered by admin'})});toast('Status updated; verify provider records');await loadAdmin();await loadAccount();}catch(e){toast(e.message)}}));
 document.querySelectorAll('[data-toggle-video]').forEach(b=>b.addEventListener('click',async()=>{try{await api(`/api/admin/videos/${b.dataset.toggleVideo}`,{method:'PATCH',body:JSON.stringify({active:false})});toast('Campaign disabled');await loadVideos();await loadAdmin();}catch(e){toast(e.message)}}));
 }catch(e){$('#adminPanel').textContent=e.message;}
}
async function refresh(){
 try{const d=await api('/api/me');currentUser=d.user;}catch(e){currentUser=null;}
 $('#authActions').hidden=!!currentUser;$('#logoutBtn').hidden=!currentUser;
 await loadVideos();await loadAccount();await loadAdmin();
}
refresh();
