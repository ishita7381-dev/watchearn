# WatchEarn — full-stack starter

A responsive Node.js + Express + PostgreSQL starter for a video/sponsored-campaign rewards website. It includes email/password signup and login, random UID, account history, campaign management, reward ledger, admin review, withdrawal requests, policy pages, Docker setup, and a provider callback **scaffold**.

## Important limitations — read before launch

This is a runnable application scaffold, **not a live money-making business and not a complete audited production service**.

- **YouTube view verification:** YouTube embeds do not give an arbitrary website a reliable server-verifiable proof that a person watched a full Short. The two provided Shorts are listed as external videos and do not automatically earn cash.
- **Reward callbacks:** `/api/provider/reward-event` is a protected integration seam. Only connect a real approved sponsored campaign/ad provider that sends authenticated server-to-server completion events. It must be independently verified and the reward budget funded. Do not call it from browser JavaScript.
- **Ads policy:** Never reward ad clicks or artificial impressions. Confirm the selected ad network explicitly permits your exact incentive model.
- **Payouts:** Withdrawals are disabled by default. No payment provider is integrated and no payment is sent. A production integration needs the provider's official API, webhooks, country eligibility checks, KYC/tax handling as required, reconciliation, idempotency, and sandbox/live testing.
- **Forgot password:** Email delivery and reset tokens are not implemented. Do not launch until a secure, expiring, single-use reset flow and email provider are configured.
- **Production hardening:** Have the app security-reviewed. Add CSRF protections appropriate to your session/auth design, email verification, account recovery, monitoring/alerting, backups, migration strategy, data deletion workflows, privacy/legal review, abuse controls, and tested budget/liability reconciliation. Do not expose the admin account or secrets.

## Quick start with Docker

Requirements: Docker Desktop / Docker Engine with Compose.

1. Extract the zip.
2. Edit `docker-compose.yml` and replace the example `SESSION_SECRET`, `REWARD_EVENT_SECRET`, admin email/password, and local database password with strong unique secrets. Never use the example values in production.
3. Run:

   ```bash
   docker compose up --build -d
   docker compose exec app npm run db:init
   ```

4. Open `http://localhost:3000`.
5. Sign in with the configured `INITIAL_ADMIN_EMAIL` and `INITIAL_ADMIN_PASSWORD`.
6. To stop: `docker compose down`. To stop and also erase the local database volume: `docker compose down -v` (destructive).

The compose file uses a local-only development configuration. Put production behind HTTPS, use managed PostgreSQL with backups, and set secure environment variables through your host's secret manager.

## Run without Docker

Requirements: Node.js 20+, PostgreSQL 14+.

1. Create a PostgreSQL database and user.
2. Copy `.env.example` to `.env`; set `DATABASE_URL`, a unique `SESSION_SECRET` (32+ characters), `INITIAL_ADMIN_EMAIL`, and a strong `INITIAL_ADMIN_PASSWORD`.
3. Install dependencies and initialize:

   ```bash
   npm install
   npm run db:init
   npm start
   ```

4. Visit `http://localhost:3000`.

## Environment variables

See `.env.example`. Never commit `.env` or add secret keys to `public/app.js`.

## Included endpoints

- `POST /api/auth/register`, `POST /api/auth/login`, `POST /api/auth/logout`
- `GET /api/me`, `GET /api/videos`
- `POST /api/withdrawals` (returns disabled until `PAYOUTS_ENABLED=true`)
- `POST /api/provider/reward-event` (authenticated server-to-server callback scaffold)
- Admin: `GET /api/admin/overview`, `/users`, `/withdrawals`
- Admin: `POST /api/admin/videos`, `PATCH /api/admin/videos/:id`
- Admin: `POST /api/admin/withdrawals/:id/review`, `POST /api/admin/rewards/:id/review`

## Database

`db/schema.sql` creates users, videos, rewards, withdrawals, ledger entries, and admin audit log tables. `scripts/init-db.js` initializes the schema and creates the first admin if the email is not already registered.

## Initial videos

The database initializer automatically seeds these two URLs as external, unfunded videos. Sign in as admin to edit their titles or manage other campaigns:

- `https://youtube.com/shorts/u4Jw7jj_R3E`
- `https://youtube.com/shorts/8EhW1Y5q7Rc`

Set them to **External video** and **Unfunded**. They will embed where permitted and link out to YouTube. Do not mark them funded or pay users for views unless YouTube terms and your business/legal arrangements explicitly permit the model and you have a valid verification/funding source.

## Manual smoke test checklist

- [ ] Register a regular user; verify a unique `WE-...` UID appears.
- [ ] Log out and log in with that account.
- [ ] Confirm ordinary user receives `403` on `/api/admin/overview`.
- [ ] Log in as admin; add a video and disable it.
- [ ] Confirm ordinary videos do not create reward credits from a browser click.
- [ ] Confirm `/api/withdrawals` is disabled while `PAYOUTS_ENABLED=false`.
- [ ] With a separate test database, configure a funded campaign and a real test provider callback. Verify a duplicate `eventId` is rejected.
- [ ] Approve a pending reward and confirm it changes the user's available balance.
- [ ] Test withdrawal reserve/reject/release and paid reconciliation only with a payment provider's sandbox.
- [ ] Verify backups, log redaction, rate limiting, session cookie flags, HTTPS, privacy requests, and incident response.

## Before launch: owner checklist

- Business/entity and applicable country/legal advice.
- Written policy approval from any ad/reward partner for the exact incentive format.
- Written review of YouTube terms for the proposed use; do not assume YouTube view counts equal verified eligible completions.
- Real campaign sponsors and a funded rewards budget.
- Payment provider account, approved payout products, supported countries/currencies, official API/webhook secrets, sandbox tests, reconciliation and dispute process.
- Email provider/domain setup for verification and password reset.
- Production domain, HTTPS, secure session secret, managed PostgreSQL, backups, monitoring, rate limits, abuse handling, and support inbox.
- Reviewed Terms, Privacy Policy, reward rules, refund/dispute process, tax disclosures, and any KYC/AML/privacy requirements.
